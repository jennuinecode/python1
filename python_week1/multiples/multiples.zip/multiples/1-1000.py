for num in range (1, 1001):
    if num % 2 != 0:
        print num
