from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submitted', methods=['POST'])
def create_user():
    name = request.form['name']
    location = request.form['location']
    fave_lang = request.form['language']
    comment = request.form['comment']
    return render_template('submitted.html' ,name = name , location = location , fave_lang = fave_lang , comment = comment)





app.run(debug=True)
