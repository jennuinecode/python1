from flask import Flask, render_template, redirect, request, session
import random

app = Flask(__name__)
app.secret_key = "This is secret_key"

@app.route('/', methods=['POST', 'GET'])
@app.route('/guess', methods=['POST', 'GET'])
def index():
    correct_guess = random.randrange(0,101)
    if request.method == 'POST':
        if int(request.form['guess']) == correct_guess:
            session['answer'] = "Good Job!"

        elif int(request.form['guess']) > correct_guess:
            session['answer'] = "Your guess is too high!"
        else:
            session['answer'] = "Your guess is too low!"
    return render_template('index.html')


app.run(debug=True)
